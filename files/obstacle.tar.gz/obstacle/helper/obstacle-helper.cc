/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */

#include "obstacle-helper.h"

namespace ns3 {

/* ... */


}