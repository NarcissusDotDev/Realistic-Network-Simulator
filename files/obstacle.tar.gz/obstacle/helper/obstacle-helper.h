/* -*- Mode:C++; c-file-style:"gnu"; indent-tabs-mode:nil; -*- */
#ifndef OBSTACLE_HELPER_H
#define OBSTACLE_HELPER_H

#include "ns3/obstacle.h"

namespace ns3 {

/* ... */

}

#endif /* OBSTACLE_HELPER_H */